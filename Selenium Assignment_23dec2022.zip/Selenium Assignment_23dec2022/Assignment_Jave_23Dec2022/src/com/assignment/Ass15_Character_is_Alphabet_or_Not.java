package com.assignment;

import java.util.Scanner;

public class Ass15_Character_is_Alphabet_or_Not{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 Scanner sc = new Scanner(System.in);
	        System.out.println("Enter a character");
	        char character=sc.next().charAt(0);
	        if( (character >= 'a' && character <= 'z') || (character >= 'A' && character <= 'Z'))
	            {
	            System.out.println(character + "is alphabet");
	            }
	        else
	        {
	            System.out.println(character + "is not a alphabet");
	        }
	    }
	}