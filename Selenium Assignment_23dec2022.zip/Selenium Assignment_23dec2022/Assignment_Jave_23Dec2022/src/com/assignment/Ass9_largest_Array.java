package com.assignment;

import java.util.Scanner;

public class Ass9_largest_Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int[] arr = new int[10];
	        int n,lar=0;
	        Scanner sc=new Scanner(System.in);  
	        System.out.println("Enter size of array");
	        n=sc.nextInt();          
	        System.out.println("Enter elements");
	        for(int i=0;i<n;i++)
	        {
	            arr[i]=sc.nextInt(); 
	        }
	        for(int i=0;i<n;i++)
	        {
	             if(arr[i]>lar)
	             {
	                 lar=arr[i];
	             }
	        }
	        System.out.println("largest element is " + lar );
	}

}
