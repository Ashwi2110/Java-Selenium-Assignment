package com.assignment;

import java.util.Arrays;

public class Ass6_Concatenate2_Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int[] arr1= {1,2,3};
	        int[] arr2= {5,6,7};
	        int a=arr1.length;
	        int b=arr2.length;
	        int[] c=new int[a+ b];
	        System.arraycopy(arr1, 0, c, 0,a);
	        System.arraycopy(arr2, 0, c, a,b);
	        System.out.println(Arrays.toString(c));

	}

}
