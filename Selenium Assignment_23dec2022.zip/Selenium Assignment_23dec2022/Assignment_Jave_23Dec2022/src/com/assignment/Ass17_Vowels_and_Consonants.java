package com.assignment;

import java.util.Scanner;

public class Ass17_Vowels_and_Consonants{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner sc = new Scanner(System.in);
	        System.out.println("Enter a string");
	        String word=sc.nextLine();
	        int vow_count=0;
	        int cons_count=0;
	        for(int i=0;i<word.length();i++)
	        {
	            if(word.charAt(i)=='a' || word.charAt(i)=='e' || word.charAt(i)=='i' || word.charAt(i)=='o' ||word.charAt(i)=='u' )
	            {
	                vow_count++;
	            }
	            else
	            {
	                cons_count++;
	            }
	        }
	        System.out.println("count of vowels " + vow_count);
	        System.out.println("count of consonants " + cons_count);
	}

}
