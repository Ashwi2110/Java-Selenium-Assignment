package com.assignment;
class SuperClass{
    int a,b;
    public SuperClass(int a, int b){
        this.a = a;
        this.b =b;
    }
    void add()
    {
        System.out.println("Parent Class Method Addition : "+(a+b));
    }

}
class Children extends SuperClass
{
    public Children(int a,int b){
        super(a,b);
    }
    void multiplication()
    {
        System.out.println("Child Class Multiplication : "+ a*b);
    }
}
public class Ass_29{
    public static void main(String args[])
    {
        Children obj = new Children(3,8);
        obj.add();
        obj.multiplication();
    }
}