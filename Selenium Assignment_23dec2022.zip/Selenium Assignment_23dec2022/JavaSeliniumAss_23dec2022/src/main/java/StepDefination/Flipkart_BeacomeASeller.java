package StepDefination;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Flipkart_BeacomeASeller {
	WebDriver driver = null;
	@Given("the browser is an open")
	public void the_browser_is_an_open() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("inside Step- a browser is open");
		String projectPath= System.getProperty("user.dir");

		System.out.println("Project path is: " +projectPath);

		System.setProperty("webdriver.chrome.driver",projectPath+"/src/main/resources/Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
		//driver.manage().window().maximize();
		//Thread.sleep(2000);
	}


	@When("user is on the Flipkart site page")
	public void user_is_on_the_flipkart_site_page() throws InterruptedException {
		System.out.println("inside Step- user is on a Flipkart site page");
		driver.navigate().to("https://www.flipkart.com/");

		driver.manage().window().maximize();
		Actions actions = new Actions(driver);
		org.openqa.selenium.interactions.Action sendEsc = actions.sendKeys(Keys.ESCAPE).build();

		sendEsc.perform();
		//Thread.sleep(1000);
	}
	@When("user click on Become a Seller")
	public void user_click_on_become_a_seller() throws InterruptedException {
		driver.findElement(By.xpath("/html/body/div[2]/div/div/button")).click();
		//driver.navigate().to("https://seller.flipkart.com/sell-online/?utm_source=fkwebsite&utm_medium=websitedirect");
		driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[4]")).click();
		System.out.println("inside Step- user click Become a Seller");
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		//Thread.sleep(2000);
	}

	@When("hits enter on board")
	public void hits_enter_on_board() throws InterruptedException {
		System.out.println("inside Step- enter on board");
		Thread.sleep(2000);
	}

	@Then("user is navigated to Become a Seller")
	public void user_is_navigated_to_become_a_seller() {
		driver.navigate().to("https://seller.flipkart.com/sell-online/?utm_source=fkwebsite&utm_medium=websitedirect");
		// Write code here that turns the phrase above into concrete actions
		System.out.println("inside Step- user is navigated to Become a Seller");

		//  driver.getPageSource().contains("Online Courses");
		driver.close();
		driver.quit();
	}

}
