package StepDefination;


import java.util.concurrent.TimeUnit;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

 

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Flipkart_login {
	  WebDriver driver;
	    @Given("User click on login page")
	    public void user_click_on_login_page() throws InterruptedException {
	    	System.setProperty("webdriver.chrome.driver","C:\\Users\\asjawale\\eclipse-workspace\\JavaSeliniumAss_23dec2022\\src\\main\\resources\\Drivers\\chromedriver.exe");
	                driver = new ChromeDriver();
	                driver.navigate().to("https://flipkart.com/");
	                driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	                Thread.sleep(3000);
	                }

	 


	    @When("^User enter (.*)$")
	    public void user_enter_mobile(String mobile)throws InterruptedException {

	    	driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	            WebElement mob =driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input"));
	            mob.sendKeys(mobile);
	            Thread.sleep(3000);
	            driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[3]/button")).click();
	    }

	    @Then("User will get successful login to flipkart home page")
	    public void user_will_get_successful_login_to_flipkart_home_page() {

	}


	}

