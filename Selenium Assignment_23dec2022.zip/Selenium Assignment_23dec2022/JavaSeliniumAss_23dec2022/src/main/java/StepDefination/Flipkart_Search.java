package StepDefination;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.cucumber.java.en.*;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Flipkart_Search {

	WebDriver driver = null;

	@Given("browser is open")
	public void browser_is_open() {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("inside Step- browser is open");
		String projectPath= System.getProperty("user.dir");
		
		System.out.println("Project path is: " +projectPath);
		
		System.setProperty("webdriver.chrome.driver",projectPath+"/src/main/resources/Drivers/chromedriver.exe");
	driver = new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
	driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
	//driver.manage().window().maximize();
	
	}


	@When("user is on Flipkart site page")
	public void user_is_on_flipkart_site_page() throws InterruptedException {
		System.out.println("inside Step- user is on Flipkart site page");
     	driver.navigate().to("https://www.flipkart.com/");
     	driver.manage().window().maximize();
     	Actions actions = new Actions(driver);
		org.openqa.selenium.interactions.Action sendEsc = actions.sendKeys(Keys.ESCAPE).build();

		sendEsc.perform();
		Thread.sleep(1000);
	}

	@When("user search for Specific product")
	public void user_search_for_specific_product() {
		System.out.println("inside Step- user search for Specific product");
		driver.findElement(By.name("q")).sendKeys ("Dell");
	}

	@And("hits enter")
	public void hits_enter() throws InterruptedException {
		System.out.println("inside Step- hits enter");
	Thread.sleep(2000);
	}

	@Then("user is navigated to search results")
	public void user_is_navigated_to_search_results() {
		System.out.println("inside Step- user is navigated to search results");
	
       //  driver.getPageSource().contains("Online Courses");
    	driver.close();
    	driver.quit();
	}
}