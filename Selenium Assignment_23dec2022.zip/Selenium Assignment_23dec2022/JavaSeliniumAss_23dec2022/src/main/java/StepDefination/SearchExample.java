package StepDefination;

import java.awt.Desktop.Action;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SearchExample {
	
	public static void main(String[]args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\asjawale\\eclipse-workspace\\JavaSeliniumAss_23dec2022\\src\\main\\resources\\Drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.flipkart.com/");
		
		driver.manage().window().maximize();
		
		Actions actions = new Actions(driver);
		org.openqa.selenium.interactions.Action sendEsc = actions.sendKeys(Keys.ESCAPE).build();

		sendEsc.perform();

		driver.findElement(By.name("q")).sendKeys ("Dell");

		driver.findElement (By.className ("L0Z3Pu")).click(); 

//		org.openqa.selenium.interactions.Action sendPageDown = actions.sendKeys(Keys.PAGE_DOWN).build();
//		sendPageDown.perform();
//		
//		try {
//			Thread.sleep(3000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
//		@Given("browser is open")
//		public void browser_is_open() {
//			System.out.println("inside Step- user enters a text in search box");
//		driver.findElement(By.name("q")).sendKeys("Automation Step by step");
//		Thread.sleep(2000);
//		}
//
//		@And("user is on Flipkart site page")
//		public void user_is_on_flipkart_site_page() {
//		    
//		}
//
//		@When("user search for Specific product")
//		public void user_search_for_specific_product() {
//		    
//		}
//
//		@When("hits enter")
//		public void hits_enter() {
//		    
//		}
//
//		@Then("user is navigated to search results")
//		public void user_is_navigated_to_search_results() {
//		    
//		}

		
	}

	
}