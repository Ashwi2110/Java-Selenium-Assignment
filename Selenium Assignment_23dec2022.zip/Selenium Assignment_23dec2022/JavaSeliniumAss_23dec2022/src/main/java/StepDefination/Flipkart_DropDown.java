//package StepDefination;
//
//import java.util.concurrent.TimeUnit;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.Keys;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.interactions.Actions;
//
//import io.cucumber.java.en.And;
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//
//public class Flipkart_DropDown {
//
//	WebDriver driver = null;
//
//	@Given("a browser should be open")
//	
//	public void a_browser_should_be_open() throws InterruptedException {
//		// Write code here that turns the phrase above into concrete actions
//		System.out.println("inside Step- a browser should be open");
//		String projectPath= System.getProperty("user.dir");
//		
//		System.out.println("Project path is: " +projectPath);
//		
//		System.setProperty("webdriver.chrome.driver",projectPath+"/src/main/resources/Drivers/chromedriver.exe");
//	driver = new ChromeDriver();
//	driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
//	driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	//driver.manage().window().maximize();
//	Thread.sleep(2000);
//	
//	}
//	
//	
//
//	@When("user needs to be on a Flipkart site page")
//	public void user_needs_to_be_on_a_flipkart_site_page() throws InterruptedException {
//		System.out.println("inside Step- user needs to be on a Flipkart site page");
//     	driver.navigate().to("https://www.flipkart.com/");
//     	
//     	driver.manage().window().maximize();
//     	Actions actions = new Actions(driver);
//		org.openqa.selenium.interactions.Action sendEsc = actions.sendKeys(Keys.ESCAPE).build();
//
//		sendEsc.perform();
//		Thread.sleep(1000);
//	}
//	
//	@When("user hover on Electronics")
//	public void user_hover_on_electronics() throws InterruptedException {
//		System.out.println("inside Step- user hover on Electronics");
//		String xp="//a[contains(text(),'Electronics')]";
//		
//		WebElement menu = driver.findElement(By.xpath(xp));
//		Actions actions = new Actions(driver);
//		actions.moveToElement(menu).perform();
//		//driver.findElement(By.
//		Thread.sleep(2000);
//	}
//
//	@And("user select Mobiles")
//	public void user_select_mobiles() throws InterruptedException {
//		driver.findElement(By.linkText("Mobiles")).click();
//		Thread.sleep(2000);
//	}
//
//	@Then("user is navigated to an Mobiles option page")
//	public void user_is_navigated_to_an_mobiles_option_page() {
//		System.out.println("inside Step- user is navigated to an Mobiles option page");
//		
//	       //  driver.getPageSource().contains("Online Courses");
//	    	driver.close();
//	    	driver.quit();
//	}
//}
