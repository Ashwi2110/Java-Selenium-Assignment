package StepDefination;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Flipkart_AppliancesFunctionality {

	WebDriver driver = null;

	@Given("a browser is open")

	public void a_browser_is_open() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("inside Step- a browser is open");
		String projectPath= System.getProperty("user.dir");

		System.out.println("Project path is: " +projectPath);

		System.setProperty("webdriver.chrome.driver",projectPath+"/src/main/resources/Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
		//driver.manage().window().maximize();
		Thread.sleep(2000);

	}



	@When("user is on a Flipkart site page")
	public void user_is_on_a_flipkart_site_page() throws InterruptedException {
		System.out.println("inside Step- user is on a Flipkart site page");
		driver.navigate().to("https://www.flipkart.com/");

		driver.manage().window().maximize();
		Actions actions = new Actions(driver);
		org.openqa.selenium.interactions.Action sendEsc = actions.sendKeys(Keys.ESCAPE).build();

		sendEsc.perform();
		Thread.sleep(1000);
	}


	@When("user click on Appliances")
	public void user_click_on_Appliances() throws InterruptedException {
		System.out.println("inside Step- user click on Appliances");
		driver.findElement(By.className("xtXmba")).click();
		Thread.sleep(2000);
	}

	@When("hits a enter")
	public void hits_a_enter() throws InterruptedException {
		System.out.println("inside Step- hits a enter");
		Thread.sleep(2000);
	}

	@Then("user is navigated to an Appliances page")
	public void user_is_navigated_to_Appliances_page() {
		driver.findElement(By.xpath("/html/body/div[2]/div/div/button")).click();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[4]")).click();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		// Write code here that turns the phrase above into concrete actions
		System.out.println("inside Step- user is navigated to an Appliances page");

		//  driver.getPageSource().contains("Online Courses");
		driver.close();
		driver.quit();
	}

}
