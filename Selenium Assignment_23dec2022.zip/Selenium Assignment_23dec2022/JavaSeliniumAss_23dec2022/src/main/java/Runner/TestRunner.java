//package Runner;
//
//import org.junit.runner.RunWith;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.remote.CapabilityType;
//import org.openqa.selenium.remote.DesiredCapabilities;
//
//import io.cucumber.junit.Cucumber;
//import io.cucumber.junit.CucumberOptions;
//import io.cucumber.junit.CucumberOptions;
//import io.cucumber.junit.Cucumber;
//
//
//
//@RunWith(Cucumber.class)
//@CucumberOptions(features = ".//src//test//resources//Feature2",
//glue = {"StepDefinition"},
//monochrome =true,tags ="@smoke",
//plugin={"pretty","html:target/HTMLReports/reports.html"}
//            )
//
//
//public class TestRunner {
//      
//}
//
